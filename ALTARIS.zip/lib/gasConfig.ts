export const GAS_CONFIG = {
  // Minimum native balance before triggering LiFi auto-refill
  minBalance: BigInt('2000000000000000'),      // 0.002 ETH
  // Amount to bridge per refill from Base → target chain
  refillAmount: BigInt('10000000000000000'),   // 0.01 ETH
  // Minimum relayer balance required to attempt a claim execution
  claimGasThreshold: BigInt('1000000000000000'), // 0.001 ETH
  // Source chain — holds the main gas reserve
  sourceChainId: 8453, // Base
}
