import { createPublicClient, http, formatEther, formatUnits } from 'viem'
import { SUPPORTED_CHAINS } from './chains'
import { detectPermit } from './permitDetector'

export interface DetectedAsset {
  chainId: number
  chainName: string
  tokenAddress: string   // 'native' for ETH/BNB/MATIC, else contract address
  symbol: string
  decimals: number
  balance: string        // human-readable
  rawBalance: string     // wei string
  usdValue: number
  supportsPermit: boolean
}

export async function scanWalletAssets(address: `0x${string}`): Promise<DetectedAsset[]> {
  const results: DetectedAsset[] = []

  await Promise.allSettled(
    SUPPORTED_CHAINS.map(async (chain) => {
      try {
        const rpc = chain.rpc || chain.publicRpc
        const client = createPublicClient({ transport: http(rpc) })

        // ── Native balance ──────────────────────────────────────────
        const nativeWei = await client.getBalance({ address })
        const nativeFloat = parseFloat(formatEther(nativeWei))
        if (nativeFloat > 0.0001) {
          results.push({
            chainId:       chain.id,
            chainName:     chain.name,
            tokenAddress:  'native',
            symbol:        chain.symbol,
            decimals:      18,
            balance:       nativeFloat.toFixed(6),
            rawBalance:    nativeWei.toString(),
            usdValue:      0,
            supportsPermit: false,
          })
        }

        // ── ERC20 tokens via Alchemy ────────────────────────────────
        // BNB Chain uses public RPC, alchemy_getTokensForOwner not available
        if (!chain.rpc.includes('alchemy.com')) return

        const res = await fetch(chain.rpc, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            jsonrpc: '2.0',
            id: 1,
            method: 'alchemy_getTokensForOwner',
            params: [address, { withMetadata: true }],
          }),
          signal: AbortSignal.timeout(8000),
        })

        if (!res.ok) return
        const data = await res.json()
        const tokens: any[] = data?.result?.tokens ?? []

        for (const token of tokens) {
          const decimals = Number(token.decimals ?? 18)
          const rawBal = BigInt(token.tokenBalance ?? '0')
          if (rawBal === 0n) continue

          const balance = parseFloat(formatUnits(rawBal, decimals))
          if (balance < 0.001) continue

          const permitSupported = await detectPermit(rpc, token.contractAddress, address)

          results.push({
            chainId:       chain.id,
            chainName:     chain.name,
            tokenAddress:  token.contractAddress as string,
            symbol:        (token.symbol ?? 'UNKNOWN') as string,
            decimals,
            balance:       balance.toFixed(4),
            rawBalance:    rawBal.toString(),
            usdValue:      0,
            supportsPermit: permitSupported,
          })
        }
      } catch {
        // Skip chain on error — scan continues for other chains
      }
    })
  )

  return results
}
