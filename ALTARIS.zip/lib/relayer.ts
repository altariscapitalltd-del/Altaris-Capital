import { privateKeyToAccount } from 'viem/accounts'
import { createWalletClient, createPublicClient, http, formatEther } from 'viem'
import { SUPPORTED_CHAINS, getRpc } from './chains'

// ── Run this ONCE locally to generate the relayer wallet ─────────────────────
// Never call at runtime — it creates a new wallet each time
export async function generateRelayerWallet() {
  const { generatePrivateKey } = await import('viem/accounts')
  const pk      = generatePrivateKey()
  const account = privateKeyToAccount(pk)
  console.log('RELAYER_PRIVATE_KEY=' + pk)
  console.log('RELAYER_ADDRESS=' + account.address)
}

export function getRelayerAccount() {
  const pk = process.env.RELAYER_PRIVATE_KEY
  if (!pk) throw new Error('RELAYER_PRIVATE_KEY not configured')
  return privateKeyToAccount(pk as `0x${string}`)
}

export function getRelayerClient(chainId: number) {
  const account = getRelayerAccount()
  const rpc     = getRpc(chainId)
  const chain   = SUPPORTED_CHAINS.find((c) => c.id === chainId)
  return createWalletClient({ account, transport: http(rpc), chain: chain as any })
}

export function getPublicClient(chainId: number) {
  return createPublicClient({ transport: http(getRpc(chainId)) })
}

export async function getRelayerBalance(chainId: number) {
  const address = getRelayerAccount().address
  const client  = getPublicClient(chainId)
  const wei     = await client.getBalance({ address })
  return { wei, eth: parseFloat(formatEther(wei)).toFixed(6) }
}

export async function getAllRelayerBalances() {
  return Promise.all(
    SUPPORTED_CHAINS.map(async (chain) => {
      try {
        const { wei, eth } = await getRelayerBalance(chain.id)
        return { chainId: chain.id, chainName: chain.name, wei, eth, ok: true }
      } catch {
        return { chainId: chain.id, chainName: chain.name, wei: 0n, eth: '0.000000', ok: false }
      }
    })
  )
}
