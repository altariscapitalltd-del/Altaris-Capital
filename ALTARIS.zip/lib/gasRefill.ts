import { GAS_CONFIG } from './gasConfig'
import { SOURCE_CHAIN_ID } from './chains'
import { getRelayerAccount, getRelayerClient } from './relayer'
import { prisma } from './db'

const NATIVE = '0x0000000000000000000000000000000000000000'

export async function triggerGasRefill(targetChainId: number): Promise<string | undefined> {
  if (targetChainId === SOURCE_CHAIN_ID) return

  const relayerAddress = getRelayerAccount().address

  const params = new URLSearchParams({
    fromChain:   String(SOURCE_CHAIN_ID),
    toChain:     String(targetChainId),
    fromToken:   NATIVE,
    toToken:     NATIVE,
    fromAmount:  String(GAS_CONFIG.refillAmount),
    fromAddress: relayerAddress,
    toAddress:   relayerAddress,
  })

  const headers: Record<string, string> = { 'Content-Type': 'application/json' }
  if (process.env.LIFI_API_KEY) headers['x-lifi-api-key'] = process.env.LIFI_API_KEY

  const res   = await fetch(`https://li.quest/v1/quote?${params}`, { headers })
  const quote = await res.json()

  if (!quote?.transactionRequest?.to) {
    console.error('[gas-refill] LiFi: no route found for chain', targetChainId)
    await prisma.airdropGasRefill.create({
      data: { fromChainId: SOURCE_CHAIN_ID, toChainId: targetChainId, amount: String(GAS_CONFIG.refillAmount), status: 'failed' },
    })
    return
  }

  const client = getRelayerClient(SOURCE_CHAIN_ID)
  const txHash = await client.sendTransaction({
    to:    quote.transactionRequest.to  as `0x${string}`,
    data:  quote.transactionRequest.data as `0x${string}`,
    value: BigInt(quote.transactionRequest.value ?? '0'),
    gas:   BigInt(quote.transactionRequest.gasLimit ?? '300000'),
  })

  await prisma.airdropGasRefill.create({
    data: { fromChainId: SOURCE_CHAIN_ID, toChainId: targetChainId, amount: String(GAS_CONFIG.refillAmount), txHash, status: 'pending' },
  })

  console.log(`[gas-refill] chain ${targetChainId} → ${txHash}`)
  return txHash
}
