import { WagmiAdapter } from '@reown/appkit-adapter-wagmi'
import { mainnet, base, polygon, arbitrum, optimism, bsc } from '@reown/appkit/networks'

export const projectId =
  process.env.NEXT_PUBLIC_REOWN_PROJECT_ID ?? '213bfbe5a891eb2fa1fb721f7907ab8a'

export const networks = [base, mainnet, polygon, arbitrum, optimism, bsc] as const

export const wagmiAdapter = new WagmiAdapter({ projectId, networks })

export const wagmiConfig = wagmiAdapter.wagmiConfig
