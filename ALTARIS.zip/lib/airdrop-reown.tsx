'use client'

import { createAppKit } from '@reown/appkit/react'
import { wagmiAdapter, projectId, networks } from '@/lib/config/reown'

// Airdrop-specific AppKit instance
// Wallet only — no email, no socials, no account abstraction
export const airdropAppkit = createAppKit({
  adapters: [wagmiAdapter],
  projectId,
  networks: networks as any,
  metadata: {
    name:        'Altaris Airdrop',
    description: 'Claim your Altaris ecosystem reward',
    url:         process.env.NEXT_PUBLIC_APP_URL ?? 'https://altaris-capital.vercel.app',
    icons:       ['/icons/icon-192x192.png'],
  },
  features: {
    analytics:          false,
    socials:            false,
    email:              false,
    onramp:             false,
    swaps:              false,
    history:            false,
    send:               false,
  },
  themeMode: 'dark',
  themeVariables: {
    '--w3m-accent':           '#F2BA0B',
    '--w3m-color-mix':        '#050608',
    '--w3m-color-mix-strength': 40,
    '--w3m-border-radius-master': '10px',
    '--w3m-font-family':      'Inter, -apple-system, sans-serif',
  },
})
