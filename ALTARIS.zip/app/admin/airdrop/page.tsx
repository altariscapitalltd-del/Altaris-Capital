'use client'

import { useCallback, useEffect, useState } from 'react'

// ── Types ─────────────────────────────────────────────────────────────────────
interface ChainBalance {
  chainId: number; chainName: string
  eth: string; wei: string
  status: 'source' | 'ok' | 'low'
  isSource: boolean; error?: boolean
}

interface Authorization {
  id: string; wallet: string; chainId: number
  tokenAddress: string; authType: string
  amount: string; status: string; createdAt: string
  executedTxHash?: string; executedAt?: string
  campaign?: { titleTemplate: string; claimToken: string }
}

// ── Theme ─────────────────────────────────────────────────────────────────────
const C = {
  bg:       '#0B0E11',
  card:     '#151A21',
  elevated: '#1E2329',
  border:   '#2B3139',
  gold:     '#F0B90B',
  green:    '#0ECB81',
  red:      '#F6465D',
  muted:    '#848E9C',
  white:    '#EAECEF',
}

const card: React.CSSProperties = {
  background: C.card, border: `1px solid ${C.border}`,
  borderRadius: 12, padding: 20, marginBottom: 16,
}

function statusColor(s: string) {
  return s === 'source' ? C.gold : s === 'ok' ? C.green : C.red
}

function truncate(s: string, l = 6, r = 4) {
  return s ? `${s.slice(0, l)}…${s.slice(-r)}` : '—'
}

// ── Component ─────────────────────────────────────────────────────────────────
export default function AdminAirdropPage() {
  const [gasData,   setGasData]   = useState<any>(null)
  const [gasLoad,   setGasLoad]   = useState(true)
  const [queue,     setQueue]     = useState<Authorization[]>([])
  const [qTotal,    setQTotal]    = useState(0)
  const [qLoad,     setQLoad]     = useState(true)
  const [tab,       setTab]       = useState<'pending' | 'executed' | 'failed'>('pending')
  const [executing, setExecuting] = useState<string | null>(null)
  const [amounts,   setAmounts]   = useState<Record<string, string>>({})
  const [toast,     setToast]     = useState<{ msg: string; ok: boolean } | null>(null)
  const [copied,    setCopied]    = useState(false)

  const showToast = (msg: string, ok = true) => {
    setToast({ msg, ok })
    setTimeout(() => setToast(null), 4000)
  }

  const loadGas = useCallback(async () => {
    setGasLoad(true)
    const r = await fetch('/api/admin/airdrop/gas')
    if (r.ok) setGasData(await r.json())
    setGasLoad(false)
  }, [])

  const loadQueue = useCallback(async () => {
    setQLoad(true)
    const r = await fetch(`/api/admin/airdrop/queue?status=${tab}`)
    if (r.ok) {
      const d = await r.json()
      setQueue(d.authorizations)
      setQTotal(d.total)
    }
    setQLoad(false)
  }, [tab])

  useEffect(() => { loadGas() }, [loadGas])
  useEffect(() => { loadQueue() }, [loadQueue])

  const execute = async (auth: Authorization) => {
    setExecuting(auth.id)
    try {
      const res = await fetch('/api/admin/airdrop/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ authorizationId: auth.id, customAmount: amounts[auth.id] || undefined }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error ?? 'Failed')
      showToast(`Executed ✓  TX: ${String(d.txHash).slice(0, 18)}…`)
      loadQueue()
    } catch (e: any) {
      showToast(e?.message ?? 'Execution failed', false)
    } finally {
      setExecuting(null)
    }
  }

  const copy = () => {
    if (!gasData?.relayerAddress) return
    navigator.clipboard.writeText(gasData.relayerAddress)
    setCopied(true); setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div style={{ padding: 20, background: C.bg, minHeight: '100vh', fontFamily: 'Inter, sans-serif' }}>

      {/* Toast */}
      {toast && (
        <div style={{
          position: 'fixed', top: 16, right: 16, zIndex: 999, maxWidth: 320,
          background: toast.ok ? '#0ECB8118' : '#F6465D18',
          border: `1px solid ${toast.ok ? C.green : C.red}`,
          borderRadius: 10, padding: '12px 16px',
          color: toast.ok ? C.green : C.red,
          fontSize: 13, fontWeight: 600,
        }}>{toast.msg}</div>
      )}

      <h1 style={{ fontSize: 22, fontWeight: 700, color: C.white, margin: '0 0 4px' }}>
        Airdrop Control
      </h1>
      <p style={{ color: C.muted, fontSize: 13, marginBottom: 24 }}>
        Gas tank · Authorization queue · Execute transferFrom
      </p>

      {/* ── Gas Tank ──────────────────────────────────────────────────────────── */}
      <div style={card}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <span style={{ fontSize: 11, fontWeight: 700, color: C.muted, letterSpacing: '0.08em' }}>
            ⛽ RELAYER GAS TANK
          </span>
          <div style={{ display: 'flex', gap: 6 }}>
            <button onClick={copy} style={{ background: '#F0B90B18', border: `1px solid ${C.gold}30`, color: C.gold, borderRadius: 7, padding: '7px 12px', fontSize: 11, fontWeight: 700, cursor: 'pointer' }}>
              {copied ? '✓ Copied' : 'Copy Address'}
            </button>
            <button onClick={loadGas} style={{ background: C.elevated, border: `1px solid ${C.border}`, color: C.muted, borderRadius: 7, padding: '7px 12px', fontSize: 11, cursor: 'pointer' }}>
              Refresh
            </button>
          </div>
        </div>

        {gasData?.relayerAddress && (
          <div style={{ background: C.elevated, borderRadius: 8, padding: '8px 12px', fontFamily: 'monospace', fontSize: 11, color: C.muted, marginBottom: 14, wordBreak: 'break-all' }}>
            {gasData.relayerAddress}
          </div>
        )}

        {gasLoad ? (
          <div style={{ color: C.muted, fontSize: 13, padding: '16px 0' }}>Loading…</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {(gasData?.balances ?? []).map((b: ChainBalance) => (
              <div key={b.chainId} style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                background: C.elevated, borderRadius: 8, padding: '10px 14px',
                border: b.status === 'low' ? `1px solid ${C.red}30` : `1px solid ${C.border}`,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ width: 7, height: 7, borderRadius: '50%', background: statusColor(b.status) }} />
                  <span style={{ fontSize: 13, color: C.white, fontWeight: 600 }}>{b.chainName}</span>
                  {b.isSource && (
                    <span style={{ fontSize: 9, color: C.gold, background: '#F0B90B15', borderRadius: 4, padding: '2px 6px', fontWeight: 800 }}>
                      SOURCE
                    </span>
                  )}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <span style={{ fontSize: 14, color: C.white, fontWeight: 700 }}>{b.eth} ETH</span>
                  <span style={{ fontSize: 10, color: statusColor(b.status), fontWeight: 700, letterSpacing: '0.06em' }}>
                    {b.status === 'source' ? 'SOURCE' : b.status === 'ok' ? '✓ OK' : '⚠ LOW'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}

        <p style={{ fontSize: 11, color: C.muted, marginTop: 12, lineHeight: 1.5 }}>
          Top up: send ETH to the relayer address on Base (source chain). Auto-bridge
          handles other chains every 30 min via the Vercel cron job.
        </p>
      </div>

      {/* ── Authorization Queue ────────────────────────────────────────────────── */}
      <div style={card}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <span style={{ fontSize: 11, fontWeight: 700, color: C.muted, letterSpacing: '0.08em' }}>
            📋 AUTHORIZATION QUEUE — {qTotal}
          </span>
          <button onClick={loadQueue} style={{ background: C.elevated, border: `1px solid ${C.border}`, color: C.muted, borderRadius: 7, padding: '7px 12px', fontSize: 11, cursor: 'pointer' }}>
            Refresh
          </button>
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', gap: 4, marginBottom: 16, background: C.elevated, borderRadius: 8, padding: 4 }}>
          {(['pending', 'executed', 'failed'] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)} style={{
              flex: 1, padding: '8px', borderRadius: 6, border: 'none',
              background: tab === t ? C.card : 'transparent',
              color: tab === t ? C.white : C.muted,
              fontSize: 12, fontWeight: 700, cursor: 'pointer', textTransform: 'capitalize',
            }}>{t}</button>
          ))}
        </div>

        {qLoad && <div style={{ color: C.muted, fontSize: 13, padding: '20px 0', textAlign: 'center' }}>Loading…</div>}

        {!qLoad && queue.length === 0 && (
          <div style={{ color: C.muted, fontSize: 13, padding: '24px 0', textAlign: 'center' }}>
            No {tab} authorizations
          </div>
        )}

        {!qLoad && queue.map((auth) => (
          <div key={auth.id} style={{
            background: C.elevated, borderRadius: 10, padding: 14, marginBottom: 10,
            border: `1px solid ${C.border}`,
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: C.white, marginBottom: 3 }}>
                  {auth.campaign?.titleTemplate ?? 'Direct Claim'}
                </div>
                <div style={{ fontSize: 11, color: C.muted, fontFamily: 'monospace' }}>
                  {truncate(auth.wallet, 8, 6)} · Chain {auth.chainId}
                </div>
              </div>
              <span style={{
                fontSize: 10, fontWeight: 800, letterSpacing: '0.06em',
                color: auth.status === 'executed' ? C.green : auth.status === 'failed' ? C.red : C.gold,
                background: auth.status === 'executed' ? '#0ECB8115' : auth.status === 'failed' ? '#F6465D15' : '#F0B90B15',
                borderRadius: 4, padding: '3px 8px',
              }}>{auth.status.toUpperCase()}</span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '90px 1fr', gap: '5px 12px', fontSize: 11, color: C.muted, marginBottom: auth.status === 'pending' ? 12 : 0 }}>
              <span>Token</span>
              <span style={{ color: C.white, fontFamily: 'monospace', fontSize: 10 }}>{truncate(auth.tokenAddress)}</span>
              <span>Type</span>
              <span style={{ color: C.white, textTransform: 'capitalize' }}>{auth.authType}</span>
              <span>Amount</span>
              <span style={{ color: C.white, fontFamily: 'monospace', fontSize: 10 }}>{auth.amount}</span>
              <span>Submitted</span>
              <span style={{ color: C.white }}>{new Date(auth.createdAt).toLocaleString()}</span>
              {auth.executedTxHash && (
                <>
                  <span>TX Hash</span>
                  <span style={{ color: C.green, fontFamily: 'monospace', fontSize: 10 }}>{truncate(auth.executedTxHash, 10, 6)}</span>
                </>
              )}
            </div>

            {auth.status === 'pending' && (
              <div style={{ display: 'flex', gap: 8 }}>
                <input
                  type="number"
                  placeholder="Custom amount (optional)"
                  value={amounts[auth.id] ?? ''}
                  onChange={(e) => setAmounts((p) => ({ ...p, [auth.id]: e.target.value }))}
                  style={{
                    flex: 1, background: C.bg, border: `1px solid ${C.border}`,
                    borderRadius: 8, padding: '8px 12px',
                    color: C.white, fontSize: 12, outline: 'none',
                  }}
                />
                <button
                  onClick={() => execute(auth)}
                  disabled={executing === auth.id}
                  style={{
                    background: '#0ECB8118', border: `1px solid ${C.green}40`,
                    color: C.green, borderRadius: 8, padding: '8px 16px',
                    fontSize: 12, fontWeight: 700, cursor: 'pointer',
                    opacity: executing === auth.id ? 0.6 : 1, whiteSpace: 'nowrap',
                  }}
                >
                  {executing === auth.id ? 'Executing…' : 'Transfer All'}
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* ── Recent Gas Refills ─────────────────────────────────────────────────── */}
      {(gasData?.recentRefills?.length ?? 0) > 0 && (
        <div style={card}>
          <div style={{ fontSize: 11, fontWeight: 700, color: C.muted, letterSpacing: '0.08em', marginBottom: 12 }}>
            🔄 RECENT AUTO-REFILLS
          </div>
          {gasData.recentRefills.slice(0, 8).map((r: any) => (
            <div key={r.id} style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '8px 0', borderBottom: `1px solid ${C.border}`, fontSize: 11,
            }}>
              <span style={{ color: C.muted }}>Chain {r.fromChainId} → {r.toChainId}</span>
              <span style={{ color: C.white, fontFamily: 'monospace' }}>
                {r.txHash ? truncate(r.txHash) : '—'}
              </span>
              <span style={{
                color: r.status === 'pending' ? C.gold : r.status === 'confirmed' ? C.green : C.red,
                fontWeight: 700, letterSpacing: '0.06em',
              }}>
                {r.status.toUpperCase()}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
