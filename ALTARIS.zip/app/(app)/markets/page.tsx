'use client'
import { useEffect, useState, useRef, useCallback } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import CoinIcon from '@/components/ui/CoinIcon'

function ShadowCard({ h = 92 }: { h?: number }) {
  return (
    <div style={{
      height: h,
      borderRadius: 18,
      background: '#050505',
      border: '1px solid rgba(255,255,255,0.06)',
      overflow: 'hidden',
      position: 'relative',
    }}>
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(110deg, transparent 18%, rgba(255,255,255,0.06) 32%, transparent 46%)', backgroundSize: '200% 100%', opacity: 0.35 }} />
      <div style={{ position: 'absolute', top: 12, left: 12, right: 76, height: 10, borderRadius: 999, background: 'rgba(255,255,255,0.06)' }} />
      <div style={{ position: 'absolute', top: 32, left: 12, width: '42%', height: 12, borderRadius: 999, background: 'rgba(255,255,255,0.08)' }} />
      <div style={{ position: 'absolute', bottom: 12, left: 12, right: 12, height: 26, borderRadius: 999, background: 'rgba(255,255,255,0.05)' }} />
    </div>
  )
}

function Sparkline({ data, color, width=60, height=28 }: { data:number[], color:string, width?:number, height?:number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d'); if (!ctx) return
    const dpr = window.devicePixelRatio||1; canvas.width=width*dpr; canvas.height=height*dpr; ctx.scale(dpr,dpr)
    if (data.length === 0) return
    const min=Math.min(...data),max=Math.max(...data),range=max-min||1
    const xs=data.map((_,i)=>(i/(data.length-1))*width)
    const ys=data.map(v=>height-((v-min)/range)*(height-4)-2)
    const grad=ctx.createLinearGradient(0,0,0,height)
    grad.addColorStop(0,color+'28'); grad.addColorStop(1,color+'00')
    ctx.beginPath(); ctx.moveTo(xs[0],ys[0]); for(let i=1;i<xs.length;i++) ctx.lineTo(xs[i],ys[i])
    ctx.lineTo(xs[xs.length-1],height); ctx.lineTo(xs[0],height); ctx.closePath()
    ctx.fillStyle=grad; ctx.fill()
    ctx.beginPath(); ctx.moveTo(xs[0],ys[0]); for(let i=1;i<xs.length;i++) ctx.lineTo(xs[i],ys[i])
    ctx.strokeStyle=color; ctx.lineWidth=1.5; ctx.lineJoin='round'; ctx.stroke()
  },[data,color,width,height])
  return <canvas ref={canvasRef} style={{width,height,display:'block'}}/>
}

type Coin = {
  id: string
  symbol: string
  name: string
  image: string
  price: number
  change24h: number
  volumeFormatted: string
  marketCapRank: number
  spark: number[]
}

const MARKET_TABS = [
  { id: 'crypto',       label: '₿ Crypto'       },
  { id: 'stocks',       label: '📈 Stocks'       },
  { id: 'defi',         label: '🏦 DeFi'          },
  { id: 'forex',        label: '💱 Forex'         },
  { id: 'bonds',        label: '🏛 Bonds'          },
  { id: 'real estate',  label: '🏠 Real Estate'   },
]

const RANK_TABS = [
  { id: 'all',     label: 'All',     type: 'all'     as const },
  { id: 'gainers', label: '↑ Gainers', type: 'gainers' as const },
  { id: 'losers',  label: '↓ Losers',  type: 'losers'  as const },
  { id: 'top_10',  label: 'Top 10',  type: 'rank'    as const, rank: 10 },
  { id: 'top_50',  label: 'Top 50',  type: 'rank'    as const, rank: 50 },
  { id: 'top_100', label: 'Top 100', type: 'rank'    as const, rank: 100 },
]

const CHAIN_TABS = [
  { id: 'ethereum-ecosystem', label: '⬡ Ethereum' },
  { id: 'bnb-chain-ecosystem', label: '◆ BNB Chain' },
  { id: 'solana-ecosystem', label: '◎ Solana' },
  { id: 'avalanche-ecosystem', label: '▲ Avalanche' },
  { id: 'polygon-ecosystem', label: '⬟ Polygon' },
  { id: 'arbitrum-ecosystem', label: '🔵 Arbitrum' },
  { id: 'optimism-ecosystem', label: '🔴 Optimism' },
  { id: 'base-ecosystem', label: '🔷 Base' },
  { id: 'defi', label: '🏦 DeFi' },
  { id: 'stablecoins', label: '💵 Stablecoins' },
  { id: 'real-world-assets-rwa', label: '🏠 RWA' },
  { id: 'artificial-intelligence', label: '🤖 AI' },
  { id: 'gaming', label: '🎮 Gaming' },
  { id: 'meme-token', label: '🐸 Memes' },
]

export default function MarketsPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const q = (searchParams?.get('q') || '').trim().toLowerCase()

  const [list, setList]             = useState<Coin[]>([])
  const [tab, setTab]               = useState('all')
  const [marketCat, setMarketCat]   = useState('crypto')
  const [loading, setLoading]       = useState(true)

  // Non-crypto markets use the live API (returns different shape — adapt it)
  const isCryptoMarket = marketCat === 'crypto'

  const fetchLiveMarket = useCallback(async (cat: string) => {
    setLoading(true)
    try {
      const res  = await fetch(`/api/markets/live?category=${encodeURIComponent(cat)}`)
      const data = await res.json().catch(() => ({ assets: [] }))
      // Shape live assets to match Coin type for display
      const adapted: Coin[] = (data.assets || []).map((a: any) => ({
        id:            a.id || a.symbol,
        symbol:        a.symbol,
        name:          a.name,
        image:         a.image || '',
        price:         a.price ?? 0,
        change24h:     a.change24h ?? 0,
        volumeFormatted: a.volume ? `$${(a.volume / 1e6).toFixed(1)}M` : '—',
        marketCapRank: 0,
        spark:         Array.isArray(a.spark) && a.spark.length ? a.spark : [0],
      }))
      setList(adapted)
    } catch {
      setList([])
    }
    setLoading(false)
  }, [])

  const fetchList = useCallback(async (categoryId?: string) => {
    setLoading(true)
    const url = categoryId
      ? `/api/markets/list?category_id=${encodeURIComponent(categoryId)}&per_page=100`
      : '/api/markets/list?per_page=100'
    try {
      const res  = await fetch(url)
      const data = await res.json().catch(() => ({ list: [] }))
      setList(data.list || [])
    } catch {
      setList([])
    }
    setLoading(false)
  }, [])

  useEffect(() => {
    if (!isCryptoMarket) {
      fetchLiveMarket(marketCat)
      return
    }
    const isChainTab = CHAIN_TABS.some(t => t.id === tab)
    if (isChainTab) fetchList(tab)
    else fetchList()
  }, [tab, marketCat, isCryptoMarket, fetchList, fetchLiveMarket])

  const filtered = list
    .filter(c => {
      if (!q) return true
      return c.symbol.toLowerCase().includes(q) || c.name.toLowerCase().includes(q)
    })
    .filter(c => {
      const r = RANK_TABS.find(t => t.id === tab)
      if (!r) return true
      if (r.type === 'gainers') return c.change24h > 0
      if (r.type === 'losers') return c.change24h < 0
      if (r.type === 'rank' && r.rank) return c.marketCapRank <= r.rank
      return true
    })
    .sort((a, b) => {
      if (tab === 'gainers') return b.change24h - a.change24h
      if (tab === 'losers') return a.change24h - b.change24h
      return a.marketCapRank - b.marketCapRank
    })

  const allTabs = [
    ...RANK_TABS,
    { id: '_divider', label: '— Chains —', type: 'divider' as any },
    ...CHAIN_TABS.map(c => ({ ...c, type: 'category' as const })),
  ]

  return (
    <div style={{ padding: '0 0 12px' }}>
      <div style={{ padding: '8px 16px 0' }}>
        {/* ── Market category tabs ── */}
        <div style={{ display: 'flex', gap: 6, overflowX: 'auto', paddingBottom: 10, scrollbarWidth: 'none' }}>
          {MARKET_TABS.map(m => (
            <button
              key={m.id}
              onClick={() => { setMarketCat(m.id); setTab('all') }}
              style={{
                padding: '7px 14px', borderRadius: 99, fontSize: 12, fontWeight: 700,
                border: '1px solid var(--border)', whiteSpace: 'nowrap', cursor: 'pointer',
                background: marketCat === m.id ? 'var(--brand-primary)' : 'var(--bg-card)',
                color:      marketCat === m.id ? '#000' : 'var(--text-secondary)',
                transition: 'all .15s',
              }}
            >{m.label}</button>
          ))}
        </div>
        {/* ── Rank / chain sub-tabs (crypto only) ── */}
        {isCryptoMarket && (
        <div style={{ display: 'flex', gap: 6, overflowX: 'auto', paddingBottom: 4, alignItems: 'center' }} className="no-scrollbar">
          {allTabs.map(t => {
            if (t.id === '_divider') {
              return <div key="_divider" style={{ width: 1, height: 20, background: 'var(--border)', flexShrink: 0, margin: '0 2px' }} />
            }
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`chip ${tab === t.id ? 'active' : ''}`}
                style={{ flexShrink: 0, fontSize: 12 }}
              >
                {t.label}
              </button>
            )
          })}
        </div>
        )}
      </div>

      <div style={{ padding: '14px 16px 0' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr auto auto 70px', gap: 8, padding: '8px 0', borderBottom: '1px solid var(--border)', marginBottom: 2 }}>
          {['Asset', 'Price', '24h', ''].map(h => (
            <span key={h} style={{ color: 'var(--text-muted)', fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{h}</span>
          ))}
        </div>

        {loading ? (
          <div style={{ display: 'grid', gap: 12, paddingTop: 10 }}>
            {Array.from({ length: 6 }).map((_, i) => <ShadowCard key={i} h={78} />)}
          </div>
        ) : (
          <>
            {filtered.map(coin => (
              <div
                key={coin.id}
                role="button"
                tabIndex={0}
                onClick={() => router.push(`/markets/${coin.symbol.toLowerCase()}`)}
                onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); router.push(`/markets/${coin.symbol.toLowerCase()}`) } }}
                style={{ display: 'grid', gridTemplateColumns: '1fr auto auto 70px', gap: 8, alignItems: 'center', padding: '13px 0', borderBottom: '1px solid var(--border)', cursor: 'pointer' }}
                className="pressable"
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  {coin.image ? (
                    <img src={coin.image} alt="" style={{ width: 38, height: 38, borderRadius: 10, objectFit: 'cover', flexShrink: 0 }} />
                  ) : (
                    <CoinIcon symbol={coin.symbol} size={38} />
                  )}
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14 }}>{coin.symbol}</div>
                    <div style={{ color: 'var(--text-muted)', fontSize: 11 }}>{coin.name}</div>
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontWeight: 700, fontSize: 14 }}>
                    ${coin.price < 0.01 ? coin.price.toFixed(6) : coin.price.toLocaleString('en-US', { minimumFractionDigits: coin.price < 1 ? 4 : coin.price < 100 ? 2 : 0, maximumFractionDigits: 8 })}
                  </div>
                  <div style={{ color: 'var(--text-muted)', fontSize: 10 }}>Vol {coin.volumeFormatted}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <span style={{ fontSize: 13, fontWeight: 700, color: coin.change24h >= 0 ? 'var(--success)' : 'var(--danger)', background: coin.change24h >= 0 ? 'var(--success-bg)' : 'var(--danger-bg)', padding: '4px 9px', borderRadius: 99, whiteSpace: 'nowrap' }}>
                    {(coin.change24h >= 0 ? '+' : '') + coin.change24h.toFixed(2)}%
                  </span>
                </div>
                <Sparkline data={coin.spark.length ? coin.spark : [coin.price, coin.price]} color={coin.change24h >= 0 ? '#0ECB81' : '#F6465D'} width={70} height={30} />
              </div>
            ))}

            {!loading && filtered.length === 0 && (
              <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>
                {q ? `No coins match "${q}"` : 'No coins in this category'}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}
