import { NextRequest, NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'
export const revalidate = 0

const FINNHUB_KEY       = process.env.FINNHUB_API_KEY
const ALPHA_VANTAGE_KEY = process.env.ALPHA_VANTAGE_KEY

// ── In-memory cache ────────────────────────────────────────────────────────
const _cache: Record<string, { data: any; ts: number }> = {}
const TTL = 5 * 60 * 1000 // 5 min

async function cached<T>(key: string, fn: () => Promise<T>): Promise<T | null> {
  if (_cache[key] && _cache[key].ts + TTL > Date.now()) return _cache[key].data
  try {
    const data = await fn()
    if (data) _cache[key] = { data, ts: Date.now() }
    return data
  } catch (e) {
    console.error(`[live] cache miss for ${key}:`, e)
    return _cache[key]?.data ?? null
  }
}

// ── Helpers ────────────────────────────────────────────────────────────────
function fmt(n: number) {
  if (n >= 1e12) return `$${(n / 1e12).toFixed(2)}T`
  if (n >= 1e9)  return `$${(n / 1e9).toFixed(2)}B`
  if (n >= 1e6)  return `$${(n / 1e6).toFixed(2)}M`
  return `$${n?.toFixed(2) ?? '0.00'}`
}

// ── Crypto (CoinGecko — free, no key needed) ───────────────────────────────
async function getCryptoData() {
  return cached('crypto', async () => {
    const res = await fetch(
      'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=50&page=1&sparkline=true',
      { signal: AbortSignal.timeout(8000) }
    )
    if (!res.ok) throw new Error('CoinGecko error')
    const raw = await res.json()
    return raw.map((c: any) => ({
      id:          c.id,
      symbol:      (c.symbol || '').toUpperCase(),
      name:        c.name,
      category:    'Crypto',
      price:       c.current_price ?? 0,
      change24h:   c.price_change_percentage_24h ?? 0,
      image:       c.image,
      spark:       c.sparkline_in_7d?.price ?? [],
      marketCap:   c.market_cap ?? 0,
      volume:      c.total_volume ?? 0,
      dailyReturn: Math.abs(c.price_change_percentage_24h ?? 0.5).toFixed(2),
      annualReturn:((Math.abs(c.price_change_percentage_24h ?? 0.5)) * 365 / 100).toFixed(1),
      riskLevel:   Math.abs(c.price_change_percentage_24h ?? 2) > 5 ? 5 : Math.abs(c.price_change_percentage_24h ?? 2) > 2 ? 4 : 3,
      minInvestment: 50,
    }))
  })
}

// ── Stocks (Finnhub real-time + Alpha Vantage overview) ────────────────────
const STOCK_SYMBOLS = [
  { symbol: 'AAPL',  name: 'Apple Inc.',          image: 'https://logo.clearbit.com/apple.com' },
  { symbol: 'MSFT',  name: 'Microsoft Corp.',      image: 'https://logo.clearbit.com/microsoft.com' },
  { symbol: 'GOOGL', name: 'Alphabet Inc.',         image: 'https://logo.clearbit.com/google.com' },
  { symbol: 'AMZN',  name: 'Amazon.com Inc.',       image: 'https://logo.clearbit.com/amazon.com' },
  { symbol: 'NVDA',  name: 'NVIDIA Corp.',           image: 'https://logo.clearbit.com/nvidia.com' },
  { symbol: 'TSLA',  name: 'Tesla Inc.',             image: 'https://logo.clearbit.com/tesla.com' },
  { symbol: 'META',  name: 'Meta Platforms Inc.',   image: 'https://logo.clearbit.com/meta.com' },
  { symbol: 'NFLX',  name: 'Netflix Inc.',           image: 'https://logo.clearbit.com/netflix.com' },
  { symbol: 'BRK.B', name: 'Berkshire Hathaway',    image: 'https://logo.clearbit.com/berkshirehathaway.com' },
  { symbol: 'JPM',   name: 'JPMorgan Chase',         image: 'https://logo.clearbit.com/jpmorganchase.com' },
  { symbol: 'V',     name: 'Visa Inc.',              image: 'https://logo.clearbit.com/visa.com' },
  { symbol: 'JNJ',   name: 'Johnson & Johnson',      image: 'https://logo.clearbit.com/jnj.com' },
  { symbol: 'WMT',   name: 'Walmart Inc.',           image: 'https://logo.clearbit.com/walmart.com' },
  { symbol: 'XOM',   name: 'ExxonMobil Corp.',       image: 'https://logo.clearbit.com/exxonmobil.com' },
  { symbol: 'PG',    name: 'Procter & Gamble',       image: 'https://logo.clearbit.com/pg.com' },
  { symbol: 'MA',    name: 'Mastercard Inc.',        image: 'https://logo.clearbit.com/mastercard.com' },
  { symbol: 'HD',    name: 'Home Depot Inc.',        image: 'https://logo.clearbit.com/homedepot.com' },
  { symbol: 'BAC',   name: 'Bank of America',        image: 'https://logo.clearbit.com/bankofamerica.com' },
  { symbol: 'PYPL',  name: 'PayPal Holdings',        image: 'https://logo.clearbit.com/paypal.com' },
  { symbol: 'COIN',  name: 'Coinbase Global',        image: 'https://logo.clearbit.com/coinbase.com' },
]

async function getStocksData() {
  if (!FINNHUB_KEY) {
    // Fallback data when no API key
    return STOCK_SYMBOLS.map((s, i) => ({
      id:          s.symbol.toLowerCase(),
      symbol:      s.symbol,
      name:        s.name,
      category:    'Stocks',
      price:       150 + i * 22,
      change24h:   (Math.random() * 4 - 1.5),
      image:       s.image,
      spark:       Array.from({ length: 20 }, (_, j) => 100 + Math.sin(j / 3 + i) * 8),
      marketCap:   0,
      volume:      0,
      dailyReturn: (Math.random() * 1.5 + 0.3).toFixed(2),
      annualReturn:((Math.random() * 1.5 + 0.3) * 365 / 100).toFixed(1),
      riskLevel:   2,
      minInvestment: 10,
    }))
  }

  return cached('stocks', async () => {
    // Fetch up to 10 symbols in parallel (Finnhub free: 60 calls/min)
    const subset = STOCK_SYMBOLS.slice(0, 15)
    const results = await Promise.allSettled(
      subset.map(async (s) => {
        const res = await fetch(
          `https://finnhub.io/api/v1/quote?symbol=${s.symbol}&token=${FINNHUB_KEY}`,
          { signal: AbortSignal.timeout(5000) }
        )
        if (!res.ok) throw new Error('finnhub error')
        const q = await res.json()
        // q: { c: current, d: change, dp: changePercent, h: high, l: low, o: open, pc: prevClose }
        if (!q.c || q.c === 0) return null
        return {
          id:           s.symbol.toLowerCase(),
          symbol:       s.symbol,
          name:         s.name,
          category:     'Stocks',
          price:        q.c,
          change24h:    q.dp ?? 0,
          image:        s.image,
          spark:        [q.o, q.l, (q.o + q.c) / 2, q.h, q.c],
          marketCap:    0,
          volume:       0,
          dailyReturn:  Math.abs(q.dp ?? 0.5).toFixed(2),
          annualReturn: ((Math.abs(q.dp ?? 0.5)) * 365 / 100).toFixed(1),
          riskLevel:    Math.abs(q.dp ?? 0) > 3 ? 4 : 2,
          minInvestment: 10,
        }
      })
    )
    return results
      .filter((r) => r.status === 'fulfilled' && r.value !== null)
      .map((r: any) => r.value)
  })
}

// ── DeFi (DefiLlama — free) ────────────────────────────────────────────────
async function getDeFiData() {
  return cached('defi', async () => {
    const res = await fetch('https://api.llama.fi/protocols', { signal: AbortSignal.timeout(8000) })
    if (!res.ok) throw new Error('DefiLlama error')
    const raw = await res.json()
    return raw.slice(0, 30).map((p: any) => ({
      id:           p.slug,
      symbol:       p.symbol || p.name.slice(0, 5).toUpperCase(),
      name:         p.name,
      category:     'DeFi',
      price:        p.tvl ?? 0,
      change24h:    p.change_1d ?? 0,
      image:        p.logo,
      spark:        [],
      marketCap:    p.tvl ?? 0,
      volume:       0,
      dailyReturn:  (Math.abs(p.change_1d ?? 1)).toFixed(2),
      annualReturn: ((Math.abs(p.change_1d ?? 1)) * 365 / 100).toFixed(1),
      riskLevel:    5,
      minInvestment: 100,
    }))
  })
}

// ── Forex (Frankfurter — free) ─────────────────────────────────────────────
async function getForexData() {
  return cached('forex', async () => {
    const res = await fetch('https://www.frankfurter.app/latest?from=USD', { signal: AbortSignal.timeout(6000) })
    if (!res.ok) throw new Error('Frankfurter error')
    const { rates } = await res.json()
    return Object.keys(rates).slice(0, 20).map((currency) => ({
      id:           `forex-${currency}`,
      symbol:       `USD/${currency}`,
      name:         `${currency} Exchange Rate`,
      category:     'Forex',
      price:        rates[currency],
      change24h:    parseFloat((Math.random() * 0.6 - 0.3).toFixed(3)),
      image:        `https://flagcdn.com/w40/${currency.toLowerCase().slice(0, 2)}.png`,
      spark:        [],
      marketCap:    0,
      volume:       0,
      dailyReturn:  (Math.random() * 0.2 + 0.05).toFixed(2),
      annualReturn: (Math.random() * 5 + 2).toFixed(1),
      riskLevel:    1,
      minInvestment: 50,
    }))
  })
}

// ── Bonds (fallback static — FRED requires API key) ───────────────────────
async function getBondsData() {
  return cached('bonds', async () => {
    // Static well-known bond data — update periodically
    return [
      { id: 'us-10y',  symbol: 'US10Y',  name: 'US 10-Year Treasury',    price: 4.45, change24h: 0.02,  riskLevel: 1, minInvestment: 1000, annualReturn: '4.45' },
      { id: 'us-2y',   symbol: 'US2Y',   name: 'US 2-Year Treasury',     price: 4.82, change24h: 0.01,  riskLevel: 1, minInvestment: 500,  annualReturn: '4.82' },
      { id: 'us-30y',  symbol: 'US30Y',  name: 'US 30-Year Treasury',    price: 4.62, change24h: 0.03,  riskLevel: 1, minInvestment: 2000, annualReturn: '4.62' },
      { id: 'corp-ig', symbol: 'CORP-IG',name: 'Investment Grade Corp.', price: 5.20, change24h: 0.05,  riskLevel: 2, minInvestment: 500,  annualReturn: '5.20' },
      { id: 'hy-bond', symbol: 'HY',     name: 'High-Yield Bond',        price: 8.10, change24h: 0.12,  riskLevel: 4, minInvestment: 200,  annualReturn: '8.10' },
      { id: 'em-bond', symbol: 'EM-BOND',name: 'Emerging Market Bond',   price: 6.50, change24h: 0.08,  riskLevel: 3, minInvestment: 300,  annualReturn: '6.50' },
    ].map((b) => ({
      ...b,
      category:     'Bonds',
      image:        '',
      spark:        [],
      marketCap:    0,
      volume:       0,
      dailyReturn:  (parseFloat(b.annualReturn) / 365).toFixed(3),
    }))
  })
}

// ── Real Estate (REITs via Finnhub) ───────────────────────────────────────
const REIT_SYMBOLS = [
  { symbol: 'VNQ',  name: 'Vanguard Real Estate ETF', image: '' },
  { symbol: 'O',    name: 'Realty Income Corp.',       image: 'https://logo.clearbit.com/realtyincome.com' },
  { symbol: 'AMT',  name: 'American Tower Corp.',      image: 'https://logo.clearbit.com/americantower.com' },
  { symbol: 'PLD',  name: 'Prologis Inc.',              image: 'https://logo.clearbit.com/prologis.com' },
  { symbol: 'WELL', name: 'Welltower Inc.',             image: '' },
  { symbol: 'DLR',  name: 'Digital Realty Trust',      image: 'https://logo.clearbit.com/digitalrealty.com' },
  { symbol: 'SPG',  name: 'Simon Property Group',      image: 'https://logo.clearbit.com/simon.com' },
]

async function getRealEstateData() {
  if (!FINNHUB_KEY) {
    return REIT_SYMBOLS.map((s, i) => ({
      id:           s.symbol.toLowerCase(),
      symbol:       s.symbol,
      name:         s.name,
      category:     'Real Estate',
      price:        60 + i * 15,
      change24h:    (Math.random() * 2 - 0.8),
      image:        s.image,
      spark:        Array.from({ length: 10 }, (_, j) => 60 + Math.sin(j + i) * 4),
      marketCap:    0,
      volume:       0,
      dailyReturn:  (Math.random() * 0.4 + 0.1).toFixed(2),
      annualReturn: (Math.random() * 8 + 4).toFixed(1),
      riskLevel:    2,
      minInvestment: 100,
    }))
  }

  return cached('realestate', async () => {
    const results = await Promise.allSettled(
      REIT_SYMBOLS.map(async (s) => {
        const res = await fetch(
          `https://finnhub.io/api/v1/quote?symbol=${s.symbol}&token=${FINNHUB_KEY}`,
          { signal: AbortSignal.timeout(5000) }
        )
        if (!res.ok) throw new Error('finnhub reit error')
        const q = await res.json()
        if (!q.c || q.c === 0) return null
        return {
          id:           s.symbol.toLowerCase(),
          symbol:       s.symbol,
          name:         s.name,
          category:     'Real Estate',
          price:        q.c,
          change24h:    q.dp ?? 0,
          image:        s.image,
          spark:        [q.o, q.l, (q.o + q.c) / 2, q.h, q.c],
          marketCap:    0,
          volume:       0,
          dailyReturn:  Math.abs(q.dp ?? 0.3).toFixed(2),
          annualReturn: ((Math.abs(q.dp ?? 0.3)) * 365 / 100).toFixed(1),
          riskLevel:    2,
          minInvestment: 100,
        }
      })
    )
    return results
      .filter((r) => r.status === 'fulfilled' && r.value !== null)
      .map((r: any) => r.value)
  })
}

// ── Route handler ──────────────────────────────────────────────────────────
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const category = (searchParams.get('category') || 'All').toLowerCase()

  try {
    // Decide which fetchers to run based on category
    const fetchMap: Record<string, () => Promise<any>> = {
      crypto:       getCryptoData,
      stocks:       getStocksData,
      defi:         getDeFiData,
      forex:        getForexData,
      bonds:        getBondsData,
      'real estate':getRealEstateData,
    }

    let assets: any[] = []

    if (category === 'all') {
      const results = await Promise.allSettled([
        getCryptoData(),
        getStocksData(),
        getDeFiData(),
        getForexData(),
        getBondsData(),
        getRealEstateData(),
      ])
      results.forEach((r) => {
        if (r.status === 'fulfilled' && r.value) assets.push(...r.value)
      })
    } else if (fetchMap[category]) {
      const data = await fetchMap[category]()
      if (data) assets = data
    } else {
      // Unknown category — return crypto
      const data = await getCryptoData()
      if (data) assets = data
    }

    // HOT = biggest absolute movers
    const hot = assets
      .filter((a) => Math.abs(a.change24h) > 2)
      .sort((a, b) => Math.abs(b.change24h) - Math.abs(a.change24h))
      .slice(0, 12)

    return NextResponse.json({ assets, hot, timestamp: Date.now() })
  } catch (error) {
    console.error('[markets/live] error:', error)
    return NextResponse.json({ assets: [], hot: [], error: 'Internal error' }, { status: 500 })
  }
}
