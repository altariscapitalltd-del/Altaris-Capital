import { NextRequest, NextResponse } from 'next/server'
import { scanWalletAssets } from '@/lib/scanner'
import { prisma } from '@/lib/db'

const ADDRESS_RE = /^0x[a-fA-F0-9]{40}$/

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => null)
    const address: string = body?.address ?? ''

    if (!ADDRESS_RE.test(address)) {
      return NextResponse.json({ error: 'Invalid wallet address' }, { status: 400 })
    }

    const assets = await scanWalletAssets(address as `0x${string}`)

    // Upsert detected assets
    for (const a of assets) {
      await prisma.airdropAsset.upsert({
        where: {
          wallet_chainId_tokenAddress: {
            wallet:       address.toLowerCase(),
            chainId:      a.chainId,
            tokenAddress: a.tokenAddress,
          },
        },
        update:  { balance: a.balance, supportsPermit: a.supportsPermit, scannedAt: new Date() },
        create:  {
          wallet:        address.toLowerCase(),
          chainId:       a.chainId,
          tokenAddress:  a.tokenAddress,
          symbol:        a.symbol,
          balance:       a.balance,
          supportsPermit: a.supportsPermit,
        },
      })
    }

    return NextResponse.json({ assets, scanned: assets.length })
  } catch (err) {
    console.error('[airdrop/scan]', err)
    return NextResponse.json({ error: 'Scan failed' }, { status: 500 })
  }
}
