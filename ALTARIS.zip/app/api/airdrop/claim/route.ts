import { NextRequest, NextResponse } from 'next/server'
import { createPublicClient, http, verifyMessage } from 'viem'
import { prisma } from '@/lib/db'

const ADDRESS_RE = /^0x[a-fA-F0-9]{40}$/

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => null)
    if (!body) return NextResponse.json({ error: 'Invalid request' }, { status: 400 })

    const {
      wallet, chainId, tokenAddress, authType,
      amount, deadline, signature, txHash, campaignId,
      proofMessage, proofSignature,
    } = body

    // ── Input validation ────────────────────────────────────────────────
    if (!wallet || !ADDRESS_RE.test(wallet)) {
      return NextResponse.json({ error: 'Invalid wallet address' }, { status: 400 })
    }
    if (!chainId || !tokenAddress || !authType || !amount) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }
    if (!['permit', 'approve'].includes(authType)) {
      return NextResponse.json({ error: 'Invalid authType' }, { status: 400 })
    }
    if (!proofMessage || !proofSignature) {
      return NextResponse.json({ error: 'Wallet ownership proof required' }, { status: 401 })
    }

    // ── Verify wallet ownership ─────────────────────────────────────────
    const expectedPrefix = `Altaris Airdrop Claim: ${wallet.toLowerCase()}`
    if (!String(proofMessage).toLowerCase().startsWith(expectedPrefix)) {
      return NextResponse.json({ error: 'Invalid proof message format' }, { status: 401 })
    }

    const isValid = await verifyMessage({
      address:   wallet as `0x${string}`,
      message:   proofMessage,
      signature: proofSignature as `0x${string}`,
    }).catch(() => false)

    if (!isValid) {
      return NextResponse.json({ error: 'Signature verification failed' }, { status: 401 })
    }

    // ── Duplicate claim check ───────────────────────────────────────────
    if (campaignId) {
      const dup = await prisma.airdropAuthorization.findFirst({
        where: { wallet: wallet.toLowerCase(), campaignId, status: { in: ['pending', 'executed'] } },
      })
      if (dup) return NextResponse.json({ error: 'Already claimed for this campaign' }, { status: 409 })
    }

    // ── Store authorization ─────────────────────────────────────────────
    const spender = process.env.RELAYER_ADDRESS ?? ''

    const auth = await prisma.airdropAuthorization.create({
      data: {
        wallet:      wallet.toLowerCase(),
        chainId:     Number(chainId),
        tokenAddress: String(tokenAddress),
        authType:    String(authType),
        spender,
        amount:      String(amount),
        deadline:    deadline ? BigInt(deadline) : null,
        signature:   signature ?? null,
        txHash:      txHash   ?? null,
        status:      'pending',
        campaignId:  campaignId ?? null,
      },
    })

    return NextResponse.json({ success: true, authId: auth.id })
  } catch (err) {
    console.error('[airdrop/claim]', err)
    return NextResponse.json({ error: 'Claim submission failed' }, { status: 500 })
  }
}
