import { NextRequest, NextResponse } from 'next/server'
import { checkAllRelayerBalances } from '@/lib/gasMonitor'

export const runtime    = 'nodejs'
export const maxDuration = 60

export async function GET(req: NextRequest) {
  const auth = req.headers.get('authorization')
  if (auth !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const results         = await checkAllRelayerBalances()
  const refillsQueued   = results.filter((r) => r.needsRefill).length

  return NextResponse.json({ ok: true, results, refillsQueued })
}
