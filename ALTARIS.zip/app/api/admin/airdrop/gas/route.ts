import { NextRequest, NextResponse } from 'next/server'
import { getAdminUser } from '@/lib/auth'
import { getAllRelayerBalances } from '@/lib/relayer'
import { GAS_CONFIG } from '@/lib/gasConfig'
import { SOURCE_CHAIN_ID } from '@/lib/chains'
import { prisma } from '@/lib/db'

export async function GET(req: NextRequest) {
  const admin = await getAdminUser(req)
  if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const [balances, recentRefills] = await Promise.all([
    getAllRelayerBalances(),
    prisma.airdropGasRefill.findMany({ orderBy: { createdAt: 'desc' }, take: 20 }),
  ])

  const enriched = balances.map((b) => ({
    ...b,
    wei: b.wei.toString(),
    status: b.isSource ? 'source' : b.wei < GAS_CONFIG.minBalance ? 'low' : 'ok',
    threshold: GAS_CONFIG.minBalance.toString(),
  }))

  return NextResponse.json({
    relayerAddress: process.env.RELAYER_ADDRESS ?? '',
    balances: enriched,
    recentRefills,
  })
}
