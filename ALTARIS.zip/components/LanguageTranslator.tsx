'use client'

/**
 * LanguageTranslator — crash-free, built-in translation
 *
 * Strategy:
 *  1. Remove Google Translate entirely (it mutates the DOM and breaks Next.js hydration)
 *  2. Set <html lang="xx"> so every modern browser (Chrome, Safari, Firefox, Edge)
 *     automatically offers / applies its own built-in page translation
 *  3. Persist the user's preferred language in localStorage
 *  4. Expose ALTARIS_LANGUAGES and applyAltarisLanguage() for the settings UI
 *
 * Result: translation works natively on every device, zero crashes, no external
 * script injected, app look is 100% unchanged.
 */

import { useEffect } from 'react'

export const ALTARIS_LANGUAGES = [
  { code: 'en',    label: 'English',    flag: '🇺🇸' },
  { code: 'ar',    label: 'Arabic',     flag: '🇸🇦' },
  { code: 'bn',    label: 'Bengali',    flag: '🇧🇩' },
  { code: 'zh-CN', label: 'Chinese',    flag: '🇨🇳' },
  { code: 'nl',    label: 'Dutch',      flag: '🇳🇱' },
  { code: 'fr',    label: 'French',     flag: '🇫🇷' },
  { code: 'de',    label: 'German',     flag: '🇩🇪' },
  { code: 'hi',    label: 'Hindi',      flag: '🇮🇳' },
  { code: 'id',    label: 'Indonesian', flag: '🇮🇩' },
  { code: 'it',    label: 'Italian',    flag: '🇮🇹' },
  { code: 'ja',    label: 'Japanese',   flag: '🇯🇵' },
  { code: 'ko',    label: 'Korean',     flag: '🇰🇷' },
  { code: 'pt',    label: 'Portuguese', flag: '🇧🇷' },
  { code: 'ru',    label: 'Russian',    flag: '🇷🇺' },
  { code: 'es',    label: 'Spanish',    flag: '🇪🇸' },
  { code: 'sw',    label: 'Swahili',    flag: '🇰🇪' },
  { code: 'th',    label: 'Thai',       flag: '🇹🇭' },
  { code: 'tr',    label: 'Turkish',    flag: '🇹🇷' },
  { code: 'ur',    label: 'Urdu',       flag: '🇵🇰' },
  { code: 'vi',    label: 'Vietnamese', flag: '🇻🇳' },
  { code: 'yo',    label: 'Yoruba',     flag: '🇳🇬' },
]

const LS_KEY = 'altaris_language'

export function getSavedLanguage(): string {
  if (typeof window === 'undefined') return 'en'
  return window.localStorage.getItem(LS_KEY) || 'en'
}

/**
 * Apply a language code.
 * Sets <html lang="xx"> — this is the signal browsers use to decide whether
 * to offer / apply automatic page translation.
 */
export function applyAltarisLanguage(code: string) {
  try {
    window.localStorage.setItem(LS_KEY, code)
  } catch {}
  document.documentElement.lang = code
}

/**
 * Mount in the app layout. Reads saved language on first render and applies it.
 * Also listens for the custom event dispatched by the settings page.
 */
export default function LanguageTranslator() {
  useEffect(() => {
    // Restore language on mount
    applyAltarisLanguage(getSavedLanguage())

    // Listen for settings page change events
    const handler = (e: Event) => {
      const code = (e as CustomEvent<{ language: string }>).detail?.language
      if (code) applyAltarisLanguage(code)
    }
    window.addEventListener('altaris:set-language', handler)
    return () => window.removeEventListener('altaris:set-language', handler)
  }, [])

  // Renders nothing — no injected UI, no DOM mutation
  return null
}
