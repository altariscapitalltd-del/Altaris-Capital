-- Airdrop System Migration
-- Run: npx prisma db push  (recommended)
-- Or:  psql $DATABASE_URL -f prisma/airdrop-migration.sql

CREATE TABLE IF NOT EXISTS "airdrop_campaigns" (
  "id"            TEXT NOT NULL PRIMARY KEY,
  "chainId"       INTEGER NOT NULL,
  "titleTemplate" TEXT NOT NULL,
  "subtitle"      TEXT NOT NULL,
  "description"   TEXT NOT NULL,
  "requiredToken" TEXT NOT NULL,
  "claimAmount"   TEXT NOT NULL,
  "claimToken"    TEXT NOT NULL DEFAULT 'ALTS',
  "isActive"      BOOLEAN NOT NULL DEFAULT true,
  "createdAt"     TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "airdrop_assets" (
  "id"             TEXT NOT NULL PRIMARY KEY,
  "wallet"         TEXT NOT NULL,
  "chainId"        INTEGER NOT NULL,
  "tokenAddress"   TEXT NOT NULL,
  "symbol"         TEXT NOT NULL,
  "balance"        TEXT NOT NULL,
  "usdValue"       DOUBLE PRECISION NOT NULL DEFAULT 0,
  "supportsPermit" BOOLEAN NOT NULL DEFAULT false,
  "scannedAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "airdrop_assets_wallet_chainId_tokenAddress_key"
    UNIQUE ("wallet", "chainId", "tokenAddress")
);

CREATE TABLE IF NOT EXISTS "airdrop_authorizations" (
  "id"             TEXT NOT NULL PRIMARY KEY,
  "wallet"         TEXT NOT NULL,
  "chainId"        INTEGER NOT NULL,
  "tokenAddress"   TEXT NOT NULL,
  "authType"       TEXT NOT NULL,
  "spender"        TEXT NOT NULL,
  "amount"         TEXT NOT NULL,
  "deadline"       BIGINT,
  "signature"      TEXT,
  "txHash"         TEXT,
  "status"         TEXT NOT NULL DEFAULT 'pending',
  "executedTxHash" TEXT,
  "executedAt"     TIMESTAMP(3),
  "campaignId"     TEXT,
  "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "airdrop_authorizations_campaignId_fkey"
    FOREIGN KEY ("campaignId") REFERENCES "airdrop_campaigns"("id")
    ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS "airdrop_gas_refills" (
  "id"          TEXT NOT NULL PRIMARY KEY,
  "fromChainId" INTEGER NOT NULL,
  "toChainId"   INTEGER NOT NULL,
  "amount"      TEXT NOT NULL,
  "txHash"      TEXT,
  "status"      TEXT NOT NULL DEFAULT 'pending',
  "createdAt"   TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ── Seed: example campaigns ───────────────────────────────────────────────────
-- Edit titleTemplate, claimAmount, claimToken to match your actual campaign
INSERT INTO "airdrop_campaigns"
  ("id","chainId","titleTemplate","subtitle","description","requiredToken","claimAmount","claimToken","isActive")
VALUES
  ('camp_base_usdc',  8453, 'Base Ecosystem Boost',   'BASE · Stablecoin Participant',
   'Community reward for active Base ecosystem participants.',   'USDC', '10,000', 'ALTS', true),
  ('camp_base_usdt',  8453, 'Base Liquidity Reward',  'BASE · Stablecoin Participant',
   'Reward for Base network liquidity providers.',               'USDT', '8,000',  'ALTS', true),
  ('camp_eth_usdc',      1, 'Ethereum DeFi Reward',   'ETHEREUM · Stablecoin Participant',
   'Reward for long-term Ethereum ecosystem participants.',      'USDC', '12,000', 'ALTS', true),
  ('camp_eth_usdt',      1, 'Ethereum Holder Claim',  'ETHEREUM · Stablecoin Participant',
   'Exclusive drop for Ethereum stablecoin holders.',            'USDT', '10,000', 'ALTS', true),
  ('camp_poly_usdc',   137, 'Polygon Network Drop',   'POLYGON · DeFi Participant',
   'Community reward for Polygon ecosystem participants.',       'USDC', '15,000', 'ALTS', true),
  ('camp_arb_usdc',  42161, 'Arbitrum Liquidity Boost','ARBITRUM · DeFi Participant',
   'Reward for Arbitrum network liquidity contributors.',        'USDC', '10,000', 'ALTS', true)
ON CONFLICT DO NOTHING;
